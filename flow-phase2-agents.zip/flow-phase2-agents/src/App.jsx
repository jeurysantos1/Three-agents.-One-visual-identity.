import FlowPhase2Agents from './FlowPhase2Agents.jsx'

export default function App() {
  return <FlowPhase2Agents />
}
